--COLISIONBOX in minetest press f5 to see where you are looking at then put these wool collor nodes on the ground in direction of north/east/west... to make colisionbox editing easier
--#1west-pink/#2down/#3south-blue/#4east-red/#5up/#6north-yelow

local messages = {
    "Drop a BubbleScum 100 blocks for the MERCILESS achievment.",
    "Give a level 20 Guinea Pig a diamond to build a Hotel!",
    "Give a diamond to a level 25 HotDog for a special reward!",
    "Feed lots of cake to Hunchback and he will stay loyal.",
    "You want money? Puch a Lawyer From Hell!",
    "Dont let those stinky FLOOBs push you around!",
    "Urintating Bums can help with landscaping. Try one today!",
    "Power your HotDog with redstone for a fire attack!",
    "Visit Sneaky Sal for those hard to find items.",
    "The longer you ride a RocketPony, the more tame it will be."
}

minetest.register_on_joinplayer(function(player)
	--minetest.chat_send_all("More Creeps and Weirdos 11.12.2016 loaded.")
    local num = math.random(10) -- set number to number of messages. help by minetest forum user pithy
    minetest.chat_send_all(messages[num])
    minetest.sound_play("amcaw_welcome")
end)


--###################
--################### HIPPO
--###################

mobs:register_mob("amcaw:aaahippo", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
    --pathfinding = true,
    stepheight = 1.2,
	damage = 3,
	hp_min = 12,
	hp_max = 35,
	armor = 150,
    reach = 2.5,
	collisionbox = {-1.7, -0.01, -1.7, 1.7, 1.9, 1.7},
	visual = "mesh",
	mesh = "amcaw_hippo.b3d",
	rotate = 180,
	textures = {
		{"amcaw_hippo.png"},
	},
	visual_size = {x=8, y=8},
	makes_footstep_sound = true,
	sounds = {
		random = "amcaw_hippo",
		damage = "amcaw_hippohurt",
		--attack = "abc",
		death = "amcaw_hippodeath",
	},
	walk_velocity = 1,
	run_velocity = 1.5,
	jump = true,
	floats = 1,
	view_range = 10,
	drops = {
		{name = "amcaw:pork_raw",
		chance = 2, min = 0, max = 2,},
	},
	water_damage = 0,
    fear_height = 6,
	lava_damage = 1,
	light_damage = 0,
	animation = {
		speed_normal = 25,		speed_run = 30,
		stand_start = 40,		stand_end = 80,
		walk_start = 0,		walk_end = 40,
		run_start = 0,		run_end = 40,
--		punch_start = 168,		punch_end = 188,
	},
})

mobs:register_egg("amcaw:aaahippo", "hippo", "amcaw_hippo_inv.png", 0)


--###################
--################### ZEBRA
--###################

mobs:register_mob("amcaw:aaazebra", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
    --pathfinding = true,
    stepheight = 1.2,
	damage = 3,
	hp_min = 12,
	hp_max = 35,
	armor = 150,
    reach = 1.8,
	collisionbox = {-1.3, -0.01, -1.3, 1.3, 1.9, 1.3},
	visual = "mesh",
	mesh = "amcaw_zebra.b3d",
	rotate = 180,
	textures = {
		{"amcaw_zebra.png"},
	},
	visual_size = {x=5, y=5},
	makes_footstep_sound = true,
	sounds = {
		--random = "abc",
		--damage = "abc",
		--attack = "abc",
		--death = "abc",
	},
	walk_velocity = 1,
	run_velocity = 1.5,
	jump = true,
	floats = 1,
	view_range = 10,
	drops = {
		{name = "amcaw:pork_raw",
		chance = 2, min = 0, max = 2,},
	},
	water_damage = 0,
    fear_height = 6,
	lava_damage = 1,
	light_damage = 0,
	animation = {
		speed_normal = 25,		speed_run = 30,
		stand_start = 40,		stand_end = 80,
		walk_start = 0,		walk_end = 40,
		run_start = 0,		run_end = 40,
--		punch_start = 168,		punch_end = 188,
	},
})

mobs:register_egg("amcaw:aaazebra", "zebra", "amcaw_zebra_inv.png", 0)


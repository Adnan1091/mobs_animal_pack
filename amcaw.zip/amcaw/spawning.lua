--[[

################# Spawn code explained    

'name' is the name of the animal/monster
    'nodes' is a list of nodenames on that the animal/monster can spawn on top of
    'neighbors' is a list of nodenames on that the animal/monster will spawn beside (default 'is {"air"} for mobs:register_spawn)
    'max_light' is the maximum of light
    'min_light' is the minimum of light
    'interval' = 60 means every 60 seconds new mob spawns (default is 30 for mobs:register_spawn)
    'chance = 9000 means 1 in every 9000th node (e.g. spawn a cow on dirt, every 9000'th node will have a chance of a cow)
    'active_object_count = 2 A map block is 16x16x16 and I cover this by having it check 32 node radius to be sure (active_object_count is counted inside this area)
    'min_height' is the maximum height the mob can spawn
    'max_height' is the maximum height the mob can spawn
    'day_toggle' true for day spawning, false for night or nil for anytime
    'on_spawn' is a custom function which runs after mob has spawned and gives self and pos values.

--]]   
    
mobs:spawn({name = "amcaw:aaahippo",
       nodes = {"default:sand", "default:dirt_with_dry_grass", "default:desert_sand"},
       min_light = 10,
       min_height = 0,
       day_toggle = true,
       active_object_count = 1,
       chance = 52000,
       interval = 200,
    })
    
mobs:spawn({name = "amcaw:aaazebra",
       nodes = {"default:sand", "default:dirt_with_dry_grass", "default:desert_sand"},
       min_light = 10,
       min_height = 0,
       day_toggle = true,
       active_object_count = 1,
       chance = 75000,
       interval = 200,
    })

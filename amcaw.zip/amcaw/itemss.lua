minetest.register_craftitem(":amcaw:zebrabody", {
	description = "zebrabody",
	inventory_image = "amcaw_zebrabody.png",
})

minetest.register_craftitem(":amcaw:zebraboots", {
	description = "zebraboots",
	inventory_image = "amcaw_zebraboots.png",
})

minetest.register_craftitem(":amcaw:zebrahelmet", {
	description = "zebrahelmet",
	inventory_image = "amcaw_zebrahelmet.png",
})

minetest.register_craftitem(":amcaw:zebrahide", {
	description = "zebrahide",
	inventory_image = "amcaw_zebrahide.png",
})

minetest.register_craftitem(":amcaw:zebralegs", {
	description = "zebralegs",
	inventory_image = "amcaw_zebralegs.png",
})

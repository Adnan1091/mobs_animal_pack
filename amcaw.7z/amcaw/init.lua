local path = minetest.get_modpath("amcaw")

-- items
dofile(path .. "/itemss.lua")

-- creeps
dofile(path .. "/creeps.lua")

-- spawning
dofile(path .. "/spawning.lua")




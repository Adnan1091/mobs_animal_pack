local path = minetest.get_modpath("amcaw")

-- items
dofile(path .. "/itemss.lua")

-- creeps
dofile(path .. "/creeps.lua")

-- spawning
dofile(path .. "/spawning.lua")

-- good creeps
--[[
dofile(path .. "/loliman.lua")
dofile(path .. "/preacher.lua")
dofile(path .. "/army_guy.lua")
dofile(path .. "/bum.lua")
dofile(path .. "/invisibleman.lua")
dofile(path .. "/kid.lua")
dofile(path .. "/oldlady.lua")
dofile(path .. "/lawyer.lua")
dofile(path .. "/nonswimmer.lua")
dofile(path .. "/ponygirl.lua")
dofile(path .. "/bigbaby.lua")
dofile(path .. "/blorp.lua")
dofile(path .. "/g.lua")
dofile(path .. "/discomole.lua")
dofile(path .. "/growbotgregg.lua")
dofile(path .. "/bubblescum.lua")
dofile(path .. "/hippo.lua")
dofile(path .. "/sneaky_sal.lua")
dofile(path .. "/camel.lua")
dofile(path .. "/flobmothership.lua")
dofile(path .. "/caveman.lua")
dofile(path .. "/cavelady.lua")
dofile(path .. "/googoat.lua")
dofile(path .. "/robotted.lua")
dofile(path .. "/robottod.lua")
dofile(path .. "/digibug.lua")
dofile(path .. "/rocketgirafe.lua")
dofile(path .. "/rockmonster.lua")
dofile(path .. "/desertlizard.lua")
dofile(path .. "/zebra.lua")
dofile(path .. "/snowdevil.lua")
dofile(path .. "/ratman.lua")
dofile(path .. "/ponie.lua")
dofile(path .. "/hunchback.lua")
dofile(path .. "/hotdog.lua")
dofile(path .. "/horsehead.lua")
dofile(path .. "/guineapig.lua")
dofile(path .. "/mandog.lua")


-- bad creeps
dofile(path .. "/floob.lua")
dofile(path .. "/blacksoul.lua")
dofile(path .. "/jockey.lua")
dofile(path .. "/mummy.lua")
dofile(path .. "/evilscientist.lua")
dofile(path .. "/prisoner.lua")
dofile(path .. "/thief.lua")
dofile(path .. "/castlecritter.lua")
dofile(path .. "/castle_king.lua")
dofile(path .. "/ragingbull.lua")
dofile(path .. "/castleguard.lua")

--]]



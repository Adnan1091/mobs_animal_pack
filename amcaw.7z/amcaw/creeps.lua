--COLISIONBOX in minetest press f5 to see where you are looking at then put these wool collor nodes on the ground in direction of north/east/west... to make colisionbox editing easier
--#1west-pink/#2down/#3south-blue/#4east-red/#5up/#6north-yelow

--###################
--################### HIPPO
--###################

mobs:register_mob("amcaw:aaahippo", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
    --pathfinding = true,
    stepheight = 1.2,
	damage = 5,
	hp_min = 12,
	hp_max = 40,
	armor = 150,
    reach = 2.5,
	collisionbox = {-1.7, -0.01, -1.7, 1.7, 1.9, 1.7},
	visual = "mesh",
	mesh = "amcaw_hippo.b3d",
	rotate = 180,
	textures = {
		{"amcaw_hippo.png"},
	},
	visual_size = {x=8, y=8},
	makes_footstep_sound = true,
	sounds = {
		random = "amcaw_hippo",
		damage = "amcaw_hippohurt",
		--attack = "abc",
		death = "amcaw_hippodeath",
	},
	walk_velocity = 1,
	run_velocity = 1.5,
	jump = true,
	floats = 1,
	view_range = 10,
	drops = {
		{name = "mobs:leather",
		chance = 3, min = 0, max = 4,},
	},
	water_damage = 0,
    fear_height = 6,
	lava_damage = 1,
	light_damage = 0,
	animation = {
		speed_normal = 25,		speed_run = 30,
		stand_start = 40,		stand_end = 80,
		walk_start = 0,		walk_end = 40,
		run_start = 0,		run_end = 40,
--		punch_start = 168,		punch_end = 188,
	},
})

mobs:register_egg("amcaw:aaahippo", "hippo", "amcaw_hippo_inv.png", 0)


--###################
--################### ZEBRA
--###################

mobs:register_mob("amcaw:aaazebra", {
	type = "monster",
	passive = true,
	attack_type = "dogfight",
    --pathfinding = true,
    stepheight = 1.2,
	damage = 3,
	hp_min = 12,
	hp_max = 35,
	armor = 150,
    reach = 1.8,
	collisionbox = {-1.3, -0.01, -1.3, 1.3, 1.9, 1.3},
	visual = "mesh",
	mesh = "amcaw_zebra.b3d",
	rotate = 180,
	textures = {
		{"amcaw_zebra.png"},
	},
	visual_size = {x=5, y=5},
	makes_footstep_sound = true,
	sounds = {
		--random = "abc",
		--damage = "abc",
		--attack = "abc",
		--death = "abc",
	},
	walk_velocity = 1,
	run_velocity = 1.5,
	jump = true,
	floats = 1,
	view_range = 10,
	drops = {
		{name = "mobs:leather",
		chance = 2, min = 0, max = 2,},
	},
	water_damage = 0,
    fear_height = 6,
	lava_damage = 1,
	light_damage = 0,
	animation = {
		speed_normal = 30,		speed_run = 45,
		stand_start = 40,		stand_end = 80,
		walk_start = 0,		walk_end = 40,
		run_start = 0,		run_end = 40,
--		punch_start = 168,		punch_end = 188,
	},
})

mobs:register_egg("amcaw:aaazebra", "zebra", "amcaw_zebra_inv.png", 0)

